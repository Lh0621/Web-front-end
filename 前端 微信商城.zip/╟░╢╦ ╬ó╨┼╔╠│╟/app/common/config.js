const ROOTPATH = "http://www.aisuizhou.cn/";

module.exports = {
	APIHOST:ROOTPATH+"app?r=",
	ROOTPATH:ROOTPATH
}